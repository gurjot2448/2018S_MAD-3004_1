//
//  DataHelper.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class DataHelper{
    var ProductList = [Int : Product]()
    
    init(){
        
        self.loadProductData()
   
    }
    func loadProductData()
    {
        ProductList = [:]
        
        let epson = Product(productID:  101, productName: "projector", manufacturer: "epson", unitPrice: 1022.1,category: ProductCategory.Appliances)
        ProductList[epson.ProductID!] = epson
        
        let mas = Product(productID:  101, productName: "maskara", manufacturer: "sukha", unitPrice: 102.1,category: ProductCategory.Appliances)
        ProductList[mas.ProductID!] = mas
    }
    
    func displayProducts(){
            for(_,value) in self.ProductList.sorted(by:{ $0.key < $1.key}){
                
                print(value.displayData())
                
            }
        
        

    }
}
