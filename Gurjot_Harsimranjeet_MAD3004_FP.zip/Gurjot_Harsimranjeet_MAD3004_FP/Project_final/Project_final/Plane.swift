//
//  Plane.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


public class Plane : IDisplay {
    
    var planeID: String?
    var totalSeat: Int
    var seatMap: String? //vector
    var seatType : SeatCategory?
    var planeType : PlaneCategory?
    var meal_type : MealType?
    
    
    var PlaneID: String{
        get{return self.planeID!}
        set{self.planeID = newValue}
    }
    
    var TotalSeat : Int{
        get{return self.totalSeat}
        set{self.totalSeat = newValue}
    }
    
    var SeatMap: String?{
        get{return self.seatMap}
        set{self.seatMap = newValue}
    }
   /* var SeatType: SeatCategory?{
        get{return self.seatType}
        set{self.seatType = newValue}
    }*/
    var PlaneType: PlaneCategory?{
        get{return self.planeType}
        set{self.planeType = newValue}
    }
    
    
    init(){
        self.planeID = ""
        self.totalSeat = 0
        self.seatMap = ""
       // self.seatType = SeatCategory.None
        self.planeType = PlaneCategory.None
        //self.meal_type = MealType.None
        
    }
    
    init(planeID: String, totalSeat: Int, seatMap: String, planeType : PlaneCategory){
        self.planeID = planeID
        self.totalSeat = totalSeat
        self.seatMap = seatMap
        //self.seatType = seatType
        self.planeType = planeType
        //self.meal_type = meal_type
        
    }
    
    func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Plane Id: \(self.planeID ?? "")"
        returnData += "\n Total Seats: \(self.totalSeat)"
        returnData += "\n Seat Map: \(self.seatMap ?? "")"
        //returnData += "\n Seat Type: \(self.seatType ?? SeatCategory.None)"
        returnData += "\n Plane Type: \(self.planeType ?? PlaneCategory.None)"
       //returnData += "\n Meal Type: \(self.meal_type ?? MealType.None)"
        
        
        return returnData
    }
    
    func addFlight(){
        
        /*print("Enter Plane ID : ")EconomyClass = 1
         case FirstClass = 2
         case BusinessClass = 3
         case None = 4        self.planeID = readLine()
        print("Enter Total Seats : ")
        self.TotalSeat = (Int)(readLine()!)!
        print("Enter Seat Map : ")
        self.seatMap = readLine()!*/
        
       /* print("Please choose Plane Type  : ")
        for planeType in PlaneCategory.allCases{
            print("Enter \(planeType.rawValue) for \(planeType)")
        }
        let choice = (Int)(readLine()!) ?? 4
        self.planeType = PlaneCategory(rawValue: choice)
        
        if choice == 1{
            print("Boeing")
        } else if  choice == 2
            
        {
            print("Airbus")
        }
        else if choice == 3
        {
            print("Lockheed")
        }
        else if choice == 4
        {
            print("Gulfstream")
        }*/
        print("Please choose Seat Type  : ")
        for seatType in SeatCategory.allCases{
            print("Enter \(seatType.rawValue) for \(seatType)")
        }
        let choice1 = (Int)(readLine()!) ?? 4
        self.seatType = SeatCategory(rawValue: choice1)
        
        if choice1 == 1{
            print("Economy Class")
        } else if  choice1 == 2
        
         {
            print("First Class")
        }
        else if choice1 == 3
        {
            print("Business Class")
        }
        
        print("choose meal:")
        for meal_type in MealType.allCases{
            print("Enter \(meal_type.rawValue) for \(meal_type)")
        }
        
        let choice2 = (Int)(readLine()!) ?? 3
        self.meal_type = MealType(rawValue: choice2)!
        
        
        if choice2 == 1{
            print("veg")
        }else{
            print("non-veg")
            print("your status:")
        if choice <= 3{
        
            print("congratulations...your flight is booked")
        }else{
            print("sorry")
        }
        /*print("Please choose Plane Type  : ")
        for seatType in PlaneCategory.allCases{
            print("Enter \(planeType?.rawValue) for \(planeType)")
        }
        
        let choice1 = (Int)(readLine()!) ?? 5
        self.planeType = PlaneCategory(rawValue: choice1)
        */
        
        
        
        
    }
}


}
