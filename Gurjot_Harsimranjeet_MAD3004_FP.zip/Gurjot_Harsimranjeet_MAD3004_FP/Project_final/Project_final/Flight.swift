//
//  Flight.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

 class Flight : Plane {
    
   //typealias flights = (flightID: Int, Flight:  String)
    
    var flightID: Int?
    var flightFrom: String?
    var flightTo: String?
    var flightScheduleDate: String? //date
    var flightType : FlightCategory?
    var price : Int?
   // private var bookFlight : [flights]
    
    
    
    var flightInfo = [
        
        1 : flightSearch(flightID: 1, flightFrom: "Toronto", flightTo: "Amritsar" , flightScheduleDate: "10-August-2018", flightType: FlightCategory.International, planeId: "P110", totalSeat: 150, planeType: PlaneCategory.Airbus),
        2 : flightSearch(flightID: 2, flightFrom: "Toronto", flightTo: "Delhi", flightScheduleDate: "15-August-2018", flightType: FlightCategory.International, planeId: "P111", totalSeat: 150, planeType: PlaneCategory.Boeing),
        3 : flightSearch(flightID: 3, flightFrom: "Toronto", flightTo: "Calgiri", flightScheduleDate: "17-August-2018", flightType: FlightCategory.Domestic, planeId: "P201", totalSeat: 100, planeType: PlaneCategory.Boeing),
        4 : flightSearch(flightID: 4, flightFrom: "Toronto", flightTo: "Sketchwan", flightScheduleDate: "18-August-2018", flightType: FlightCategory.Domestic, planeId: "P202", totalSeat: 100, planeType: PlaneCategory.Gulfstream)
    ]
    
    
    
   
    
    
    
    override init(){
        
        self.flightID = 0
        self.flightFrom = ""
        self.flightTo = ""
        self.flightScheduleDate = ""
        self.flightType = FlightCategory.None
        self.price = 0
        //self.bookFlight = []
        super.init()
        
        
    }
    
    
    
    init(flightID:  Int, flightFrom: String , flightTo: String,  flightScheduleDate : String, flightType : FlightCategory,planeID :String,totalSeat : Int,seatMap: String, planeType: PlaneCategory, price : Int) {
        
        self.flightID = flightID
        self.flightFrom = flightFrom
        self.flightTo = flightTo
        self.flightScheduleDate = flightScheduleDate
        self.flightType = flightType
        self.price = price
       
        super.init(planeID: planeID, totalSeat: totalSeat, seatMap: seatMap, planeType: planeType)
    }
    
   convenience  init(flightID: Int){
    self.init(flightID: flightID, flightFrom: "", flightTo: "", flightScheduleDate: "", flightType: FlightCategory.None, planeID: "", totalSeat: 0, seatMap: "", planeType: PlaneCategory.None, price: 0)
    }
   /*convenience override init(flightID: Int,planeID :String,totalSeat :Int,seatMap: String,seatType: SeatCategory, planeType: PlaneCategory){
        self.flightID = flightID
    super.init(planeID: <#T##String#>, totalSeat: <#T##Int#>, seatMap: <#T##String#>, seatType: <#T##SeatCategory#>, planeType: <#T##PlaneCategory#>)
    }*/
    
    override func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Flight ID: \(self.flightID)"
        returnData += "\n Flight From: \(self.flightFrom ?? "")"
        returnData += "\n Flight To: \(self.flightTo ?? "")"
        returnData += "\n Flight Schedule Date: \(self.flightScheduleDate ?? "")"
        returnData += "\n Flight Type: \(self.flightType ?? FlightCategory.None)"
        returnData += "\n plane Id: \(self.planeID ?? "")"
        returnData += "\n Total Seat: \(self.totalSeat ?? 0)"
        returnData += "\n Seat Map: \(self.seatMap ?? "")"
        returnData += "\n Plane Type: \(self.planeType ?? PlaneCategory.None)"
        returnData += "\n Price: \(self.price ?? 0)"
        
        
        
        return returnData
    }
    
   
    
        

        override func addFlight(){
        //print("Enter Flight ID : ")
        //self.flightID = (Int)(readLine()!)!
       if self.flightID! <= 3
       {
        super.addFlight()
        
       }else{
        print("Sorry we dont have this one")
        }
        /*print("Enter Flight from : ")
        self.flightFrom = readLine()
        print("Enter Flight To: ")
        self.flightTo = readLine()
        print("Enter Flight Schedule Date : ")
        self.flightScheduleDate = readLine()
        print("Please choose flight type:")
        for flightType in FlightCategory.allCases{
            print("Enter \(flightType.rawValue) for \(flightType)")
        }
        
        /*let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" 
        
        let formateDate = dateFormatter.date(from:flightScheduleDate!)!
        dateFormatter.dateFormat = "MM-dd-yyyy"
        
        print ("Print :\(dateFormatter.string(from: formateDate))")
        flightScheduleDate = dateFormatter.string(from: formateDate)
        print("Please choose Seat Type  : ")*/
        
       /* for seatType in FlightCategory.allCases{
            print("Enter \(seatType.rawValue) for \(flightType)")
        }*/
        
        let choice = (Int)(readLine()!) ?? 3
        self.flightType = FlightCategory(rawValue: choice)
        
        if choice == 1{
           print("Domestic")
        }else{
        print("International")
        
        
    }*/
    
}
    
    func chooseFlightId(flightID: Int) throws{
        
        guard let reqFlight = flightInfo[flightID] else{
            throw BookingError.notAvailable
        }
      print("Flight is available")
        
    }
}

struct flightSearch{
    var flightID: Int
    var flightFrom : String
    var flightTo: String
    var flightScheduleDate: String
    var flightType: FlightCategory
    var planeId: String
    var totalSeat: Int
    var planeType: PlaneCategory
}

enum BookingError: Error{
    case notAvailable
    
    
}


    
    
    



