//
//  Chooseflight.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//
import Foundation


class ChooseFlight{

typealias flights = (flightID: Int, Flight:  String)

    var bookFlight : [flights]

    init(){
        self.bookFlight = []
}

   
    func cancelFlight(){
        if !bookFlight.isEmpty {
           // print("Review your Flight \n \(self.displayData())")
            
            print("Please enter Flight ID to remove from the order : ")
            let selectedFlightID : Int = (Int)(readLine()!)!
            var flightIndex = -1
            
            for (index, item) in self.bookFlight.enumerated(){
                if (item.flightID == selectedFlightID){
                    flightIndex = index
                }
            }
            
            if flightIndex != -1{
                self.bookFlight.remove(at: flightIndex)
                print("The product is removed from your order")
            }
        }else{
            print("You have no item in your order")
}
    /*override convenience init(flightID: Int){
        
    self.init(flightID: flightID, flightFrom: "unknown", flightTo: "unknown", flightScheduleDate: "unknown", flightType: FlightCategory.None, planeID: "Unknown", totalSeat: 0, seatMap: "Unknown", seatType: SeatCategory.None, planeType: PlaneCategory.None, meal_type: MealType.None)
    }
    
    var flightInfo = [
        
        1 : flightSearch(flightID: 1, flightFrom: "Toronto", flightTo: "Vancouver", flightScheduleDate: "10-August-2018", flightType: FlightCategory.Domestic),
        2 : flightSearch(flightID: 2, flightFrom: "Toronto", flightTo: "Calgiri", flightScheduleDate: "15-August-2018", flightType: FlightCategory.Domestic),
        3 : flightSearch(flightID: 3, flightFrom: "Toronto", flightTo: "Delhi", flightScheduleDate: "16-August-2018", flightType: FlightCategory.International),
        //4 : flightSearch(flightID: 4, flightFrom: "Toronto", flightTo: "Amritsar", flightScheduleDate: "17-August-2018", flightType: FlightCategory.International),
    ]
    
    func chooseFlightId(flightId: Int) throws{
        
        guard let reqFlight = flightInfo[flightId] else{
            throw BookingError.notAvailable
        }
        
        
    }
}

struct flightSearch{
    var flightID: Int
    var flightFrom : String
    var flightTo: String
    var flightScheduleDate: String
    var flightType: FlightCategory
}

enum BookingError: Error{
    case notAvailable
    
    
}*/
}

}

