//
//  main.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

var choice = 1
let dataHelper = DataHelper()
var passenger = Passenger()
var flight = Flight()
var f1 = Flight().flightID
var f2 = Flight().flightID


while choice != 5{
    print("\n----What would you like to do today !----")
    print("\t 1 : Search flight ")
    print("\t 2 : Add Details")
    print("\t 3 : Add flight ")
   // print("\t 4 :check status:")
    print("\t 4 : Update Details")
    print("\t 5: Exit ")
    print("-----------------------------------------")
    print("Enter you choice please : ")
    choice = (Int)(readLine()!)!
    
    switch choice{
    case 1:
        dataHelper.displayFlight()
    case 2:
        passenger.addPassenger()
         print( passenger.displayData())
    case 3:
        
        print("Enter flight id: ")
        var f1 = (Int)(readLine()!)!
        
        do{
        
        
        try flight.chooseFlightId(flightID:f1 )
        
    }catch is BookingError{
        print("sorry...we dont have this route")
    }
        if f1 <= 4{
           
            flight.addFlight()
            print("""
              _____________________
              Details are Submitted
              _____________________
              """)
            print("Status : Reserved")
        }else if f1 > 4{
            print(" Status : Not Reserved")
        }
        
           
    
        
    case 4:
         passenger.updatePassenger()
        print( passenger.displayData())
        
    
    case 5:
        
        exit(0)
    default:
        print("Please enter valid menu option.")
    }}
