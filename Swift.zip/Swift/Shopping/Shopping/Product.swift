//
//  Product.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Product : IDisplay{
    private var productID : Int?
    private var productName : String?
    private var manufacturer : String?
    private var unitPrice : Double?
    
    var ProductID : Int? {
        get{ return self.productID}
        set{ self.productID = newValue}
    }
        
    var ProductName : String?{
        get{ return self.productName}
        set{ self.productName = newValue}
    }
    
    var UnitPrice : Double? {
        get{ return self.unitPrice}
        set{ self.unitPrice = newValue}
    }
    
    var Manufacturer : String?{
        get{ return self.manufacturer}
        set{ self.manufacturer = newValue}
    }
    
    init(){
        self.productID = 0
        self.productName = ""
        self.manufacturer = ""
        self.unitPrice = 0.0
    }
    
    init(productID: Int, productName: String, manufacturer: String, unitPrice: Double){
        self.productID = productID
        self.productName = productName
        self.manufacturer = manufacturer
        self.unitPrice = unitPrice
    }


func displayData() -> String{
    var returnData = ""
    
    returnData += "\n Product ID : \(self.productID ?? 0 )"
    returnData += "\n Product Name : \(self.productName ?? "")"
    returnData += "\n Manufacturer : \(self.manufacturer ?? "" )"
    returnData += "\n Unit Price : \(self.unitPrice ?? 0.0 )"
    
    return returnData
    }

    func newProduct(){
        print("Enter Product ID : ")
        self.productID = (Int)(readLine()!)!
        print("Enter Product Name : ")
        self.productName = readLine()
        print("Enter Manufacturer : ")
        self.manufacturer = readLine()
        print("Enter Unit Price : ")
        self.unitPrice = (Double)(readLine()!)
        
    }
}
















































