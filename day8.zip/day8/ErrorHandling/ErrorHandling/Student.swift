//
//  Student.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
//public class Student

 class Student{
   
   var name: String?
   static var accNo : Int?
   static var countst : Int = 0
    
    init(){
        self.name = "Unknown"
        Student.accNo = 123456
        Student.countst += 1
    }
    
    func display()
    {
        
        print("Student Name \(self.name ?? "Unknown")")
        print("Student accNo. \(Student.accNo ?? 000)")
        
    }
    
    static func getStudentCount() -> Int{
        return countst
    }
    
}

class PartTime : Student{
    
    var hours: Int?
    
    
    override init(){
        
         super.init()
         self.hours = 10
   
    }
    
    override func display() {
        print(" Hours : \(self.hours  ?? 000)")
    }
}
