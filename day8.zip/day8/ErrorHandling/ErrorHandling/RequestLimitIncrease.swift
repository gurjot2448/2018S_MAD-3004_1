//
//  RequestLimitIncrease.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class RequestLimitIncrease{
    
    var accountInfo = [
   
        "S1100" : requestFromAccount(type: "Saving",balance: 2321.45),
        "S1200" : requestFromAccount(type: "Saving",balance: 3000.45),
        "S1300" : requestFromAccount(type: "Cheqing",balance: 8921.45),
        "S1400" : requestFromAccount(type: "Saving",balance: 23091.45)
    
    ]
    
    func increaseLimit(accountNo: String) throws{
        
        guard let reqAcc = accountInfo[accountNo] else{
            throw limitIncreaseError.Ineligible
        
        }
        
        guard reqAcc.type == "Saving" else{
            
            throw limitIncreaseError.noSavingAccount
        
        }
        
        guard reqAcc.balance >= 5000 else{
           
            throw
            
                limitIncreaseError.insufficientBalance(BalanceNeeded: 5000 - reqAcc.balance)
       
        }
        
        print("Congratulations!...Your request is approved")//when any error in system occurs then tht gives this error
    }
    
    struct requestFromAccount{
      
        var type: String
        var balance:Double
    
    }
}

enum limitIncreaseError : Error{
   
    case Ineligible
    case noSavingAccount
    case insufficientBalance(BalanceNeeded: Double)

}
