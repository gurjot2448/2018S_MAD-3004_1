//
//  Flight.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class Flight : IDisplay {
    
    var flightID: Int?
    var flightFrom: String?
    var flightTo: String?
    var flightScheduleDate: String? //date
    var flightType : FlightCategory?
    //var flightAirlineID :
    //var flightAirplaneID :
    //var flightPilotID :
    
    var FlightID: Int?{
        get{return self.flightID!}
        set{self.flightID = newValue}
    }
    
    var FlightFrom : String?{
        get{return self.flightFrom}
        set{self.flightFrom = newValue}
    }
    var FlightTo: String?{
        get{return self.flightTo}
        set{self.flightTo = newValue}
    }
    var FlightScheduleDate: String?{
        get{return self.flightScheduleDate}
        set{self.flightScheduleDate = newValue}
    }
    var FlighType: FlightCategory?{
        get{return self.flightType}
        set{self.flightType = newValue}
    }
    /* var FlightTo: String?{
     get{return self.flightTo}
     set{self.flightTo = newValue}
     }
     var FlightTo: String?{
     get{return self.flightTo}
     set{self.flightTo = newValue}
     }
     
     var FlightTo: String?{
     get{return self.flightTo}
     set{self.flightTo = newValue}
     }*/
    
    
    
    init(){
        self.flightID = 0
        self.flightFrom = ""
        self.flightTo = ""
        self.flightScheduleDate = ""
        self.flightType = FlightCategory.None
        
        
        
    }
    init( flightFrom: String , flightTo: String,  flightScheduleDate : String, flightType : FlightCategory) {
        
       
        self.flightFrom = flightFrom
        self.flightTo = flightTo
        self.flightScheduleDate = flightScheduleDate
        self.flightType = flightType
        
    }
    
    init(flightID: Int ){
        self.flightID = flightID
    }
    
    func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Flight ID: \(self.flightID)"
        returnData += "\n Flight From: \(self.flightFrom ?? "")"
        returnData += "\n Flight To: \(self.flightTo ?? "")"
        returnData += "\n Flight Schedule Date: \(self.flightScheduleDate ?? "")"
        returnData += "\n Seat Type: \(self.flightType ?? FlightCategory.None)"
        
        
        
        return returnData
    }
    
    func addFlight(){
        print("Enter Flight ID : ")
        self.flightID = (Int)(readLine()!)!
        print("Enter Flight from : ")
        self.flightFrom = readLine()
        print("Enter Flight To: ")
        self.flightTo = readLine()
        print("Enter Flight Schedule Date : ")
        self.flightScheduleDate = readLine()
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" 
        
        let formateDate = dateFormatter.date(from:flightScheduleDate!)!
        dateFormatter.dateFormat = "MM-dd-yyyy"
        
        print ("Print :\(dateFormatter.string(from: formateDate))")
        flightScheduleDate = dateFormatter.string(from: formateDate)
        print("Please choose Seat Type  : ")
        
        for seatType in FlightCategory.allCases{
            print("Enter \(seatType.rawValue) for \(flightType)")
        }
        let choice = (Int)(readLine()!) ?? 3
        self.flightType = FlightCategory(rawValue: choice)
        
        
    }
    
    
}

