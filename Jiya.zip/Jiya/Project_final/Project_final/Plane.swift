//
//  Plane.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class Plane : IDisplay {
    var planeID: String?
    var totalSeat: Int
    var seatMap: String? //vector
    var seatType : SeatCategory?
    var planeType : PlaneCategory?
    
    
    var PlaneID: String{
        get{return self.planeID!}
        set{self.planeID = newValue}
    }
    
    var TotalSeat : Int{
        get{return self.totalSeat}
        set{self.totalSeat = newValue}
    }
    
    var SeatMap: String?{
        get{return self.seatMap}
        set{self.seatMap = newValue}
    }
    var SeatType: SeatCategory?{
        get{return self.seatType}
        set{self.seatType = newValue}
    }
    var PlaneType: PlaneCategory?{
        get{return self.planeType}
        set{self.planeType = newValue}
    }
    
    
    init(){
        self.planeID = ""
        self.totalSeat = 0
        self.seatMap = ""
        self.seatType = SeatCategory.None
        self.planeType = PlaneCategory.None
        
    }
    
    init(planeID: String, totalSeat: Int, seatMap: String, seatType: SeatCategory, planeType : PlaneCategory){
        self.planeID = planeID
        self.totalSeat = totalSeat
        self.seatMap = seatMap
        self.seatType = seatType
        self.planeType = planeType
        
    }
    
    func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Plane Id: \(self.planeID ?? "")"
        returnData += "\n Total Seats: \(self.totalSeat)"
        returnData += "\n Seat Map: \(self.seatMap ?? "")"
        returnData += "\n Seat Type: \(self.seatType ?? SeatCategory.None)"
        returnData += "\n Plane Type: \(self.planeType ?? PlaneCategory.None)"
        
        
        return returnData
    }
    
    func addPlane(){
        print("Enter Plane ID : ")
        self.planeID = readLine()
        print("Enter Total Seats : ")
        self.TotalSeat = (Int)(readLine()!)!
        print("Enter Seat Map : ")
        self.seatMap = readLine()!
        
        print("Please choose Seat Type  : ")
        for seatType in SeatCategory.allCases{
            print("Enter \(seatType.rawValue) for \(seatType)")
        }
        let choice = (Int)(readLine()!) ?? 4
        self.seatType = SeatCategory(rawValue: choice)
        
        print("Please choose Plane Type  : ")
        for seatType in PlaneCategory.allCases{
            print("Enter \(planeType?.rawValue) for \(planeType)")
        }
        let choice1 = (Int)(readLine()!) ?? 5
        self.planeType = PlaneCategory(rawValue: choice1)
        
        
        
        
        
    }
}


