//
//  Chooseflight.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-26.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class ChooseFlight{
    var flightInfo = [
        
        1 : flightSearch(flightID: 1, flightFrom: "Toronto", flightTo: "Vancouver", flightScheduleDate: "10-August-2018", flightType: FlightCategory.Domestic),
        2 :flightSearch(flightID: 2, flightFrom: "Toronto", flightTo: "Calgiri", flightScheduleDate: "15-August-2018", flightType: FlightCategory.Domestic),
        3 :flightSearch(flightID: 3, flightFrom: "Toronto", flightTo: "Delhi", flightScheduleDate: "16-August-2018", flightType: FlightCategory.International),
        4 : flightSearch(flightID: 4, flightFrom: "Toronto", flightTo: "Amritsar", flightScheduleDate: "17-August-2018", flightType: FlightCategory.International),
        ]
    
    func chooseFlightId(flightId: Int) throws{
        guard let reqFlight = flightInfo[flightId] else{
            throw BookingError.notAvailable
        }
        
        print("Congratulations!..Your request is approved.")
    }
}

struct flightSearch{
    var flightID: Int
    var flightFrom : String
    var flightTo: String
    var flightScheduleDate: String
    var flightType: FlightCategory
}

enum BookingError: Error{
    case notAvailable
    
    
}

