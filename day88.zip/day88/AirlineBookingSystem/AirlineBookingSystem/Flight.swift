//
//  Flight.swift
//  AirlineBookingSystem
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Flight: AirlineDetails,Employee1,Plane_Type1{
    
   
    
    
    
    
    var flightID : String?
    var flightFrom : String?
    var flightTo : String?
    var flightScheduleDate : String?
    var flight_airlines_Id : Int?
    var flightAirplaneId : String?
    var flightPilotId : String?
    
    var employeeID: Int?
    
    var employeeName: String?
    
    var emp_email: String?
    
    var emp_mobile: String?
    
    var emp_address: String?
    
    var designation: String?
    
    var SINnumber: String?
    
    var plane_type_id : String?
    var plane_type_total_seats : Int?
    var plane_type_seat_map : String?
    
    
    
    //default initializer of plane_type / constructor
    override init(){
        
       self.plane_type_id = ""
        self.plane_type_total_seats = 0
        self.plane_type_seat_map = ""
       
        self.flightID = ""
        self.flightFrom = ""
        self.flightTo = ""
        self.flightScheduleDate = ""
        
        self.flightAirplaneId = ""
        self.flightPilotId = ""
        
        
        self.employeeID = 0
        self.employeeName = ""
        self.emp_email = ""
        self.emp_mobile = ""
        self.emp_address = ""
        self.designation = ""
        self.SINnumber = ""
        super.init()
       
        
        
    }
    
     init(employeeID: Int, employeeName: String, emp_email: String, emp_mobile: String, emp_address: String, designation: String, SINnumber: String, plane_type_id : String,  plane_type_total_seats : Int, plane_type_seat_map  : String, flightID : String, flightFrom: String, flightTo: String, flightScheduleDate: String, flightAirplaneId: String, flightPilotId: String,flight_airlines_Id: Int, airlinesID: Int, airlinesDescription: String, airlinesType: String) {
        
        self.employeeID = employeeID
        self.employeeName = employeeName
        self.emp_email = emp_email
        self.emp_mobile = emp_mobile
        self.emp_address = emp_address
        self.designation = designation
        self.SINnumber = SINnumber
        
        
        //
        self.plane_type_id = plane_type_id
        self.plane_type_total_seats = plane_type_total_seats
        self.plane_type_seat_map = plane_type_seat_map
        
        
        //
        self.flightID = flightID
        self.flightFrom = flightFrom
        self.flightTo = flightTo
        self.flightScheduleDate = flightScheduleDate
        self.flightAirplaneId =  flightAirplaneId
        self.flightPilotId = flightPilotId
        self.flight_airlines_Id = flight_airlines_Id
        
        super.init(airlinesID: airlinesID, airlinesDescription: airlinesDescription, airlinesType: airlinesType)
        
    }
    
    //parameterized initializer of employee1
    
//    required init(employeeID: Int, employeeName: String, emp_email: String, emp_mobile: String, emp_address: String, designation: String, SINnumber: String, airlinesID: Int, airlinesDescription: String, airlinesType: String) {
//        super.init(airlinesID: airlinesID, airlinesDescription: airlinesDescription, airlinesType: airlinesType)
//        //        self.init(employeeID: <#T##Int#>, employeeName: <#T##String#>, emp_email: <#T##String#>, emp_mobile: <#T##String#>, emp_address: <#T##String#>, designation: <#T##String#>, SINnumber: <#T##String#>)
//        //        self.employeeID = employeeID
//        //        self.employeeName = employeeName
//        //        self.emp_email = emp_email
//        //        self.emp_mobile = emp_mobile
//        //        self.emp_address = emp_address
//        //        self.designation = designation
//        //        self.SINnumber = SINnumber
//
//
//    }
    
    //parameterized initializer of plane type
//
//    required convenience init( plane_type_id : String,  plane_type_total_seats : Int, plane_type_seat_map  : String){
//        self.init()
//        self.plane_type_id = plane_type_id
//        self.plane_type_total_seats = plane_type_total_seats
//        self.plane_type_seat_map = plane_type_seat_map
//
//
//    }
//
    
//    convenience init(flightID : String, flightFrom: String, flightTo: String, flightScheduleDate: String, flightAirplaneId: String, flightPilotId: String,flight_airlines_Id: Int){
//        self.init()
//        self.flightID = flightID
//        self.flightFrom = flightFrom
//        self.flightTo = flightTo
//        self.flightScheduleDate = flightScheduleDate
//        self.flightAirplaneId = flightAirplaneId
//        self.flightPilotId = flightPilotId
//
////        super.init(airlinesID: 101, airlinesDescription:"land", airlinesType: "abc")
//
//    }
    
//    override init(airlinesID: Int, airlinesDescription: String, airlinesType: String){
//        super.init(airlinesID: airlinesID, airlinesDescription: airlinesDescription, airlinesType: airlinesType)
//    }
    
    
    
    
    
    
    override func registerUser(){
        print("Enter Flight Id : ")
        self.flightID = readLine()!
        print("Enter Flight From : ")
        self.flightFrom = readLine()!
        print("Enter Flight To : ")
        self.flightTo = readLine()!
        print("Enter Flight Schedule Date : ")
        self.flightScheduleDate = readLine()!
        print("Enter Flight Airline Id : ")
        self.flight_airlines_Id = (Int)(readLine()!)!
        print("Enter Flight Airplane Id : ")
        self.flightAirplaneId = readLine()!
        print("Enter Flight Pilot Id : ")
        self.flightPilotId = readLine()!
        super.registerUser()
    }
    
    func addPlaneTYpe(){
        
        print("Enter plane type Id : ")
        self.plane_type_id = readLine()!
        print("Enter plane_type_total_seats : ")
        self.plane_type_total_seats = (Int)(readLine()!)!
        print("Enter plane_type_seat_map  : ")
        self.plane_type_seat_map = readLine()!
        
    }
    
    
    /*func displayData() -> String{
        var returnData = ""
        
        if self.employeeID != nil{
            returnData += "Employee ID : \(self.employeeID )"
        }
        if self.employeeName != nil{
            returnData += "\n Employee Name : " + self.employeeName!
        }
        if self.email != nil{
            returnData += "\n Employee Email : " + self.email!
        }
        if self.mobile != nil{
            returnData += "\n Employee Mobile : " + self.mobile!
        }
        if self.address != nil{
            returnData += "\n Employee Address : " + self.address!
        }
        if self.designation != nil{
            returnData += "\n Employee Designation : " + self.designation!
        }
        if self.SINnumber != nil{
            returnData += "\n Employee SINnumber : " + self.SINnumber!
        }
        return returnData
    }
    */
    
    func displayData1(){
        print("Reservation Id : \(self.Reservation_id ?? 0)")
        print("Flight id: \(self.res_flight_id ?? "unknown")")
        print("Reservation Description : \(self.reservation_description ?? "Unknown")")
        print("Date : \(self.res_date ?? "Unknown")")
        print("Seat number : \(self.res_seat_number ?? "Unknown")")
        print("Status : \(self.res_status ?? "Unknown")")
        print("Meal type: \(self.res_meal_type ?? "Unknown")")
    }
    
}
    
    
    
    
    
   
    
   

    
    
    
    
    
    
    
    
    
    
   
    




























