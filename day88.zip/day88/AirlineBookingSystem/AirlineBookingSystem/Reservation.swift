//
//  Reservation.swift
//  AirlineBookingSystem
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Reservation: Flight,Passenger1{
    
    
    
    var Reservation_id : Int?
    
    var res_flight_id : String?
    private var reservation_description : String?
    private var res_date : String?
    private var res_seat_number : String?
    private var res_status : String?
    private var res_meal_type : String?
    
    var Reservation_description: String?{
        get{
            return self.reservation_description
        }
        set{
            self.reservation_description = newValue
        }
    }
    
    var Res_date: String?{
        get{
            return self.res_date
        }
        set{
            self.res_date = newValue
        }
    }
    
    var Res_seat_number: String?{
        get{
            return self.Res_seat_number
        }
        set{
            self.res_seat_number = newValue
        }
    }
    var Res_status: String?{
        get{
            return self.Res_status
        }
        set{
            self.Res_status = newValue
        }
    }
    
    var Res_meal_type: String?{
        get{
            return self.Res_meal_type
        }
        set{
            self.Res_meal_type = newValue
        }
    }
    
    var passengerId : Int?
    var passportNumber : String?
    var name : String?
    var pass_address : String?
    var pass_email : String?
    var pass_mobile : String?
    var date_of_birth : String?
    
    
   
    //default initializer / constructor of reservation and passenger
    
    override init(){
        
        self.Reservation_id = 0
    
        self.reservation_description = ""
        self.res_date = ""
        self.res_seat_number = ""
        self.res_status = ""
        self.res_meal_type = ""
        self.passengerId = 0
        self.passportNumber = ""
        self.name = ""
        self.pass_address = ""
        self.pass_email = ""
        self.pass_mobile = ""
        self.date_of_birth = ""
        super.init()
        
        }
    
    //parameterized initializer of reservation

    init( Reservation_id: Int, res_flight_id:String,reservation_description: String, res_date: String,res_seat_number: String,res_status: String, res_meal_type: String,employeeID: Int, employeeName: String, emp_email: String, emp_mobile: String, emp_address: String, designation: String, SINnumber: String, plane_type_id : String,  plane_type_total_seats : Int, plane_type_seat_map  : String, flightID : String, flightFrom: String, flightTo: String, flightScheduleDate: String, flightAirplaneId: String, flightPilotId: String,flight_airlines_Id: Int, airlinesID: Int, airlinesDescription: String, airlinesType: String,passengerId: Int,passportNumber: String, name: String ,address: String,email: String,mobile: String,date_of_birth: String) {
        
    
        
        self.Reservation_id = Reservation_id
        self.reservation_description = reservation_description
        self.res_date = res_date
        self.res_seat_number = res_seat_number
        self.res_status = res_status
        self.res_meal_type = res_meal_type
        
        self.employeeID = employeeID
        self.employeeName = employeeName
        self.emp_email = emp_email
        self.emp_mobile = emp_mobile
        self.emp_address = emp_address
        self.designation = designation
        self.SINnumber = SINnumber
        
        
        //
        self.plane_type_id = plane_type_id
        self.plane_type_total_seats = plane_type_total_seats
        self.plane_type_seat_map = plane_type_seat_map
        
        
        //
        self.flightID = flightID
        self.flightFrom = flightFrom
        self.flightTo = flightTo
        self.flightScheduleDate = flightScheduleDate
        self.flightAirplaneId =  flightAirplaneId
        self.flightPilotId = flightPilotId
        self.flight_airlines_Id = flight_airlines_Id
        
        //super.init(airlinesID: airlinesID, airlinesDescription: airlinesDescription, airlinesType: airlinesType)
        self.airlinesID = airlinesID
        self.airlinesDescription = airlinesDescription
        self.airlinesType = airlinesType
        
        self.passengerId = passengerId
        self.passportNumber = passportNumber
        self.name = name
        self.pass_address = address
        self.pass_email = email
        self.pass_mobile = mobile
        self.date_of_birth = date_of_birth
        
    }
    
    
    //display function of reservation
    
        override func displayData() -> String {
        var returnData = ""
        
        if self.Reservation_id != nil{
            returnData += "\n Reservation Id: \(self.Reservation_id)"
        }
        
        if self.res_flight_id != nil{
            returnData += "\n Flight Id: \(self.res_flight_id)"
        }
        
        if self.reservation_description != nil{
            returnData += "\n Reservation Description:" +  self.reservation_description!
        }
        if self.res_date != nil{
            returnData += "\n Date:" +  self.res_date!
        }
        if self.res_seat_number != nil{
            returnData += "\n Seat number:" +  self.res_seat_number!
        }
        if self.res_status != nil{
            returnData += "\n Status:" +  self.res_status!
        }
        if self.res_meal_type != nil{
            returnData += "\n Meal:" +  self.res_meal_type!
        }
        return returnData
        
    }
    
    //display function of reservation
    
    func displayData1(){
        print("Reservation Id : \(self.Reservation_id ?? 0)")
        print("Flight id: \(self.res_flight_id ?? "unknown")")
        print("Reservation Description : \(self.reservation_description ?? "Unknown")")
        print("Date : \(self.res_date ?? "Unknown")")
        print("Seat number : \(self.res_seat_number ?? "Unknown")")
        print("Status : \(self.res_status ?? "Unknown")")
        print("Meal type: \(self.res_meal_type ?? "Unknown")")
    }
    
    
    //passenger function
    
    func addPassenger()
    {
        print("Enter PassengerId : ")
        self.passengerId = (Int)(readLine()!)!
        print("Enter your PassportNumber : ")
        self.passportNumber = readLine()!
        print("Enter your Name : ")
        self.name = readLine()
        print("Enter Address: ")
        self.pass_address = readLine()!
        print("Enter email : ")
        self.pass_email = readLine()!
        print("Enter your mobile number : ")
        self.pass_mobile = readLine()!
        print("Enter date_of_birth : ")
        self.date_of_birth = readLine()!
        super.registerUser()
        
    }
    
     }
    
    
    
    
   

    
    
 

      
 
   
    
   
    
    

    

