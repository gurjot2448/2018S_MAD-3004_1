//
//  main.swift
//  AirlineBookingSystem
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var dataHelper = DataHelper()
dataHelper.displayPassenger()

var gurjot1 = Flight(employeeID: 1, employeeName: "h", emp_email: "h", emp_mobile: "5", emp_address: "k", designation:"m", SINnumber: "7", plane_type_id: "kl", plane_type_total_seats: 9, plane_type_seat_map: "onr", flightID: "f11", flightFrom: "canada", flightTo: "brampton", flightScheduleDate: "4-5-2018", flightAirplaneId: "a1", flightPilotId: "p1", flight_airlines_Id: 21, airlinesID: 21, airlinesDescription: "as", airlinesType: "abc")
//gurjot.addPassenger()
  gurjot1.displayData1()



