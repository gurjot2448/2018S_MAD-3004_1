//
//  main.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation






var gurjot1 = Passenger(passengerID: 1, passengerPassportNumber: "ps123", passengerName: "Gurjot", passengerMobile: "6476802706", passengerEmail: "gurjot031995@gmail.com", passengerAddress: "Brampton", passengerBirthDate: "19 march 1995",meal_type:MealType.veg)

gurjot1.addPassenger()
gurjot1.displayData()

var dataHelper = DataHelper()
dataHelper.displayFlight()

var f1 = ChooseFlight()

var gurjot2 = Flight(flightID: 1, flightFrom: "canada", flightTo: "toronto", flightScheduleDate:" 16 august", flightType: FlightCategory.Domestic, planeID: "e3", totalSeat: 5, seatMap: "rter", seatType: SeatCategory.FirstClass, planeType: PlaneCategory.Airbus)
gurjot2.addFlight()

do{
    try f1.chooseFlightId(flightId: 1)
    
}catch is BookingError{
    print("sorry...we dont have this route")
    
}catch{
    print("congratulations.. your flight is booked")
}
