//
//  Datahelper.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class DataHelper{
    
    
    var FlightList = [Int : Flight]()
    
    
    init(){
        
self.loadFlightData()
        
    }
    
    
    
    
    
    
    
    
    
    func loadFlightData(){
        
        FlightList = [:]
       
        
       
        
        let domes1 = Flight(flightID: 1, flightFrom: "Toronto", flightTo: "Amritsar", flightScheduleDate: "20-August-2018", flightType: FlightCategory.International, planeID: "P102", totalSeat: 100, seatMap: "B4", seatType: SeatCategory.BusinessClass, planeType: PlaneCategory.Boeing)
        FlightList[domes1.flightID!] = domes1
        
        let domes2 = Flight(flightID: 2, flightFrom: "Toronto", flightTo: "Calgiri", flightScheduleDate: "21-August-2018", flightType: FlightCategory.Domestic, planeID: "P103", totalSeat: 50, seatMap: "C3", seatType: SeatCategory.FirstClass, planeType: PlaneCategory.Gulfstream)
        FlightList[domes2.flightID!] = domes2
        
        let domes3 = Flight(flightID: 3, flightFrom: "Toronto", flightTo: "Delhi", flightScheduleDate: "23-August-2018", flightType: FlightCategory.International, planeID: "P104", totalSeat: 100, seatMap: "A2", seatType: SeatCategory.BusinessClass, planeType: PlaneCategory.Gulfstream)
        FlightList[domes3.flightID!] = domes3
        
    }
    
    
    
    func displayFlight(){
     
     for (_, value) in self.FlightList.sorted(by: { $0.key < $1.key} ){
     
     print(value.displayData())
     
     }
     
     }
    
    
}

