//
//  Flight.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class Flight : Plane {
    
    var flightID: Int?
    var flightFrom: String?
    var flightTo: String?
    var flightScheduleDate: String? //date
    var flightType : FlightCategory?
    
    
    
    
    
    
   
    
    
    
    override init(){
        
        self.flightID = 0
        self.flightFrom = ""
        self.flightTo = ""
        self.flightScheduleDate = ""
        self.flightType = FlightCategory.None
        super.init()
        
        
    }
    init(flightID:  Int, flightFrom: String , flightTo: String,  flightScheduleDate : String, flightType : FlightCategory,planeID :String,totalSeat : Int,seatMap: String,seatType: SeatCategory, planeType: PlaneCategory) {
        
        self.flightID = flightID
        self.flightFrom = flightFrom
        self.flightTo = flightTo
        self.flightScheduleDate = flightScheduleDate
        self.flightType = flightType
        super.init(planeID:planeID , totalSeat: totalSeat, seatMap: seatMap, seatType: seatType, planeType: planeType)
    }
    
   /*convenience override init(flightID: Int,planeID :String,totalSeat :Int,seatMap: String,seatType: SeatCategory, planeType: PlaneCategory){
        self.flightID = flightID
    super.init(planeID: <#T##String#>, totalSeat: <#T##Int#>, seatMap: <#T##String#>, seatType: <#T##SeatCategory#>, planeType: <#T##PlaneCategory#>)
    }*/
    
    override func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Flight ID: \(self.flightID)"
        returnData += "\n Flight From: \(self.flightFrom ?? "")"
        returnData += "\n Flight To: \(self.flightTo ?? "")"
        returnData += "\n Flight Schedule Date: \(self.flightScheduleDate ?? "")"
        returnData += "\n Flight Type: \(self.flightType ?? FlightCategory.None)"
        
        
        
        return returnData
    }
    
    override func addFlight(){
        print("Enter Flight ID : ")
        self.flightID = (Int)(readLine()!)!
        super.addFlight()
        /*print("Enter Flight from : ")
        self.flightFrom = readLine()
        print("Enter Flight To: ")
        self.flightTo = readLine()
        print("Enter Flight Schedule Date : ")
        self.flightScheduleDate = readLine()
        print("Please choose flight type:")
        for flightType in FlightCategory.allCases{
            print("Enter \(flightType.rawValue) for \(flightType)")
        }
        
        /*let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd" 
        
        let formateDate = dateFormatter.date(from:flightScheduleDate!)!
        dateFormatter.dateFormat = "MM-dd-yyyy"
        
        print ("Print :\(dateFormatter.string(from: formateDate))")
        flightScheduleDate = dateFormatter.string(from: formateDate)
        print("Please choose Seat Type  : ")*/
        
       /* for seatType in FlightCategory.allCases{
            print("Enter \(seatType.rawValue) for \(flightType)")
        }*/
        
        let choice = (Int)(readLine()!) ?? 3
        self.flightType = FlightCategory(rawValue: choice)
        
        if choice == 1{
           print("Domestic")
        }else{
        print("International")
        
        
    }*/
    
    
}

}
