//
//  Reservation.swift
//  AirlineBookingSystem
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Reservation{
    
    var Reservation_id : Int?
    var res_pass_id : String?
    var res_flight_id : String?
    private var reservation_description : String?
    private var res_date : String?
    private var res_seat_number : String?
    private var res_status : String?
    private var res_meal_type : String?
    
    var Reservation_description: String?{
        get{
            return self.reservation_description
        }
        set{
            self.reservation_description = newValue
        }
    }
    
    var Res_date: String?{
        get{
            return self.res_date
        }
        set{
            self.res_date = newValue
        }
    }
    
    var Res_seat_number: String?{
        get{
            return self.Res_seat_number
        }
        set{
            self.res_seat_number = newValue
        }
    }
    var Res_status: String?{
        get{
            return self.Res_status
        }
        set{
            self.Res_status = newValue
        }
    }
    
    var Res_meal_type: String?{
        get{
            return self.Res_meal_type
        }
        set{
            self.Res_meal_type = newValue
        }
    }
    //default initializer / constructor
    init(){
        
        self.Reservation_id = 0
        self.res_pass_id = ""
        self.res_flight_id = ""
        self.reservation_description = ""
        self.res_date = ""
        self.res_seat_number = ""
        self.res_status = ""
        self.res_meal_type = ""
        
    }
    
    //parameterized initializer
    init(  Reservation_id: Int, plane_type_seat_map  : String){
        
        self.Reservation_id = 0
        self.res_pass_id = ""
        self.res_flight_id = ""
        self.reservation_description = ""
        self.res_date = ""
        self.res_seat_number = ""
        self.res_status = ""
        self.res_meal_type = ""
    }
    
    
}
