//
//  main.swift
//  AirlineBookingSystem
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var dataHelper = DataHelper()
dataHelper.displayPassenger()

var gurjot = Reservation(passengerId: 1, passportNumber: "F101", name: "landing at 6 pm on 25 july", address: "25-6-2018", email:"S101", mobile:"reserved", date_of_birth: "veg")
func addPassenger(){
    
}
