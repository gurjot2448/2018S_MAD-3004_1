//
//  Datahelper.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class DataHelper{
    
    
    var FlightList = [Int : Flight]()
    
    
    init(){
        
self.loadFlightData()
        
    }
    
    
    
    
    
    
    
    
    
    func loadFlightData(){
        
        FlightList = [:]
       
        
       
        
        let domes1 = Flight(flightID: 1, flightFrom: "Toronto", flightTo: "Amritsar", flightScheduleDate: "20-August-2018", flightType: FlightCategory.International, planeID: "P101", totalSeat: 100, seatMap: "a-b-c-d", seatType: SeatCategory.BusinessClass, planeType: PlaneCategory.Airbus, meal_type: MealType.veg)
        FlightList[domes1.flightID!] = domes1
        
        let domes2 = Flight(flightID: 2, flightFrom: "Toronto", flightTo: "Calgiri", flightScheduleDate: "22-August-2018", flightType: FlightCategory.Domestic, planeID: "P102", totalSeat: 50, seatMap: "a-b-c-d", seatType: SeatCategory.EconomyClass, planeType: PlaneCategory.Boeing, meal_type: MealType.nonveg)
        FlightList[domes2.flightID!] = domes2
        
        let domes3 = Flight(flightID: 3, flightFrom: "Toronto", flightTo: "Delhi", flightScheduleDate: "30-August-2018", flightType: FlightCategory.International, planeID: "P103", totalSeat: 100, seatMap: "a-b-c-d", seatType: SeatCategory.FirstClass, planeType: PlaneCategory.Gulfstream, meal_type: MealType.veg)
        FlightList[domes3.flightID!] = domes3
        
    }
    
    
    
    func displayFlight(){
     
     for (_, value) in self.FlightList.sorted(by: { $0.key < $1.key} ){
     
     print(value.displayData())
     
     }
     
     }
    
    
    
    
}

