//
//  main.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

var choice = 1
let dataHelper = DataHelper()
var passenger = Passenger()
var flight = Flight()
var f1 = Flight().flightID
var f2 = Flight().flightID


while choice != 5{
    print("\n----What would you like to do today !----")
    print("\t 1 : Search flight ")
    print("\t 2 : Add Details")
    print("\t 3 : Add flight ")
    print("\t 4 :check status:")
    print("\t 5 : Update Details")
    print("\t 6: Exit ")
    print("-----------------------------------------")
    print("Enter you choice please : ")
    choice = (Int)(readLine()!)!
    
    switch choice{
    case 1:
        dataHelper.displayFlight()
    case 2:
        passenger.addPassenger()
    case 3:
        
        print("Enter flight id: ")
        var f1 = (Int)(readLine()!)!
        
        do{
        
        //self.flightID = (Int)(readLine()!)!
        //var f = (Int)(readLine()!)!
        
        //if f > 3 {
        //  print("sorry for your inconvenience")
        // }else{
        try flight.chooseFlightId(flightID:f1 )
        //print("congratulations...your flight is booked")
    }catch is BookingError{
        print("sorry...we dont have this route")
    }
        if f1 <= 3{
           
            flight.addFlight()
            print("""
              _____________________
              Details are Submitted
              _____________________
              """)
        }
           
    case 4:
            f1 = f2
            if f2! <= 3{
                print("Status : Reserved")
            }else{
                print(" Status : Not Reserved")
            }
        
    case 5:
         passenger.updatePassenger()
        print( passenger.displayData())
        
        
    case 6:
        exit(0)
    default:
        print("Please enter valid menu option.")
    }



/*var gurjot1 = Passenger(passengerID: 1, passengerPassportNumber: "ps123", passengerName: "Gurjot", passengerMobile: "6476802706", passengerEmail: "gurjot031995@gmail.com", passengerAddress: "Brampton", passengerBirthDate: "19 march 1995", meal_type:MealType.veg)

gurjot1.addPassenger()
gurjot1.displayData()

var dataHelper = DataHelper()
dataHelper.displayFlight()

var gurjot2 = Flight(flightID: 1, flightFrom: "canada", flightTo: "toronto", flightScheduleDate:" 16 august", flightType: FlightCategory.Domestic, planeID:"e3", totalSeat: 5, seatMap: "rter", seatType: SeatCategory.FirstClass, planeType: PlaneCategory.Airbus)
gurjot2.addFlight()
*/






}
