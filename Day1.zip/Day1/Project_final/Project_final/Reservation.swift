//
//  Reservation.swift
//  Project_final
//
//  Created by MacStudent on 2018-07-24.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation


class Reservation {
    
    var reservationID: Int = 0
    var reservationDescription: String?
    
    var reservationFlightID : Int?
    var reservationDate: String? //date
    var reservationSeatNumber: String?
    var reservationStatus: String?
    var reservationMealType: String?
    
    
    
    
    
  
    
     init(){
        
        self.reservationID = 0
        self.reservationDescription = ""
        
        self.reservationFlightID = 0
        self.reservationDate = ""
        self.reservationSeatNumber = ""
        self.reservationStatus = ""
        self.reservationMealType = ""
    
        
        
    }
    
    init( reservationID: Int, reservationDescription: String , reservationFlightID : Int, reservationDate: String,  reservationSeatNumber: String, reservationStatus: String, reservationMealType: String) {
        
        
        self.reservationID = reservationID
        self.reservationDescription = reservationDescription
        
        self.reservationFlightID = reservationFlightID
        self.reservationDate = reservationDate
        self.reservationSeatNumber = reservationSeatNumber
        self.reservationStatus = reservationStatus
        self.reservationMealType = reservationMealType
        
        
    }
    
    
    
    
    
    
    
     func displayData() -> String {
        var returnData = ""
        
        //returnData += "\n Flight ID: \(self.flightID)"
        returnData += "\n Reservation ID: \(self.reservationID)"
        returnData += "\n Reservation Description: \(self.reservationDescription ?? "")"
        returnData += "\n Reservation Date: \(self.reservationDate ?? "")"
        returnData += "\n Reservation Seat Number : \(self.reservationSeatNumber ?? "")"
        returnData += "\n Reservation Status: \(self.reservationStatus ?? "")"
        returnData += "\n Rreservation Meal Type: \(self.reservationMealType ?? "")"
        
        
        return returnData
    }
    
    func addReservation(){
        print("Enter Reservation ID : ")
        self.reservationID = (Int)(readLine()!)!
        print("Enter Reservation Description : ")
        self.reservationDescription = readLine()
        
        print("Enter Reservation Date : ")
        self.reservationDate = readLine()
        print("Enter Reservation Seat Number : ")
        self.reservationSeatNumber = readLine()
        print("Enter Reservation Status : ")
        self.reservationStatus = readLine()
        print("Enter Reservation Meal Type : ")
        self.reservationMealType = readLine()
        
    }
    
    
}



